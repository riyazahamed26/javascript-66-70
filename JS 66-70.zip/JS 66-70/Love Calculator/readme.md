# Love Calculator

Love Calculator is a fun web application built with HTML5 and CSS3. Users can enter their name and their partner's name, and the calculator will generate a random love percentage between them, displaying the result.

## How to Use
1. Open the `index.html` file in your web browser.
2. Enter your name and your partner's name in the provided fields.
3. Click the "Calculate" button to see the love percentage between you and your partner.

## Tech Stack Used
- HTML5
- CSS3

Enjoy using the Love Calculator to have some fun and see how strong your love connection is!

Feel free to customize and enhance this app to add more features or styling as desired.
